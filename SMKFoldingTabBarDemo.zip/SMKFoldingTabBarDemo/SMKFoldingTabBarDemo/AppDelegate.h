//
//  AppDelegate.h
//  SMKFoldingTabBarDemo
//
//  Created by Mac on 17/5/8.
//  Copyright © 2017年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

